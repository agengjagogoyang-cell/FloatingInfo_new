package id.crosshair.info;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.platform.PlayerAdapter;
import org.bukkit.entity.Player;

/** Dipisah supaya class LuckPerms baru di-load kalau pluginnya memang ada. */
final class LuckPermsHook {

    private final PlayerAdapter<Player> adapter;

    private LuckPermsHook(LuckPerms lp) {
        this.adapter = lp.getPlayerAdapter(Player.class);
    }

    static LuckPermsHook create() {
        return new LuckPermsHook(LuckPermsProvider.get());
    }

    String prefix(Player p) {
        return adapter.getMetaData(p).getPrefix();
    }

    String group(Player p) {
        User u = adapter.getUser(p);
        return u == null ? null : u.getPrimaryGroup();
    }
}
