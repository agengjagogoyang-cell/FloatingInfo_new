package id.crosshair.info;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CrosshairInfo extends JavaPlugin implements Listener {

    private static final int HEARTS = 10;
    private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

    private static final class State {
        BossBar bar;
        UUID target;
        int miss;
        double shown;
        String title = "";
        boolean visible;
    }

    private final Map<UUID, State> states = new HashMap<UUID, State>();
    private BukkitTask task;

    private LuckPermsHook luckPerms;
    private VaultHook vault;
    private EssentialsHook essentials;
    private boolean hexSupported;

    // config cache
    private double range;
    private double rayWidth;
    private int interval;
    private int graceCycles;
    private boolean smoothHide;
    private Set<String> disabledWorlds = new HashSet<String>();
    private BarColor barColor;
    private BarStyle barStyle;
    private String nameColor;
    private String separator;
    private String heartSymbol;
    private String heartFull;
    private String heartHalf;
    private String heartEmpty;
    private boolean rankEnabled;
    private boolean usePrefix;
    private boolean fallbackGroup;
    private String groupFormat;
    private Set<String> hideGroups = new HashSet<String>();
    private boolean useNick;
    private boolean moneyEnabled;
    private String moneyFormat;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        hexSupported = minorVersion() >= 16;
        hookPlugins();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        startTask();
    }

    @Override
    public void onDisable() {
        if (task != null) task.cancel();
        for (State s : states.values()) {
            if (s.bar != null) s.bar.removeAll();
        }
        states.clear();
    }

    // ------------------------------------------------------------ setup

    private void hookPlugins() {
        if (getServer().getPluginManager().getPlugin("LuckPerms") != null) {
            try {
                luckPerms = LuckPermsHook.create();
            } catch (Throwable t) {
                getLogger().warning("LuckPerms terdeteksi tapi gagal di-hook: " + t.getMessage());
            }
        }
        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            try {
                vault = VaultHook.create();
            } catch (Throwable t) {
                getLogger().warning("Vault terdeteksi tapi gagal di-hook: " + t.getMessage());
            }
        }
        if (getServer().getPluginManager().getPlugin("Essentials") != null) {
            essentials = EssentialsHook.create();
        }
        getLogger().info("Hook -> LuckPerms: " + (luckPerms != null)
                + ", EssentialsX: " + (essentials != null)
                + ", Vault: " + (vault != null));
    }

    private void loadSettings() {
        FileConfiguration c = getConfig();
        range = Math.max(0.5, c.getDouble("range", 2.0));
        rayWidth = Math.max(0.0, c.getDouble("ray-width", 0.15));
        interval = Math.max(1, c.getInt("check-interval-ticks", 2));
        int graceTicks = Math.max(0, c.getInt("hide-grace-ticks", 6));
        graceCycles = Math.max(1, graceTicks / interval);
        smoothHide = c.getBoolean("smooth-hide", true);

        disabledWorlds = new HashSet<String>(c.getStringList("disabled-worlds"));

        barColor = parseEnum(BarColor.class, c.getString("display.bar-color", "RED"), BarColor.RED);
        barStyle = parseEnum(BarStyle.class, c.getString("display.bar-style", "SOLID"), BarStyle.SOLID);
        nameColor = c.getString("display.name-color", "&f");
        separator = c.getString("display.separator", " &8| ");
        heartSymbol = c.getString("display.heart-symbol", "\u2665");
        heartFull = c.getString("display.heart-full", "&c");
        heartHalf = c.getString("display.heart-half", "&6");
        heartEmpty = c.getString("display.heart-empty", "&8");

        rankEnabled = c.getBoolean("rank.enabled", true);
        usePrefix = c.getBoolean("rank.use-luckperms-prefix", true);
        fallbackGroup = c.getBoolean("rank.fallback-to-group", true);
        groupFormat = c.getString("rank.group-format", "&7[{group}]");
        hideGroups = new HashSet<String>();
        List<String> hg = c.getStringList("rank.hide-groups");
        for (String g : hg) hideGroups.add(g.toLowerCase(Locale.ROOT));

        useNick = c.getBoolean("name.use-essentials-nickname", true);
        moneyEnabled = c.getBoolean("money.enabled", false);
        moneyFormat = c.getString("money.format", "&e$%s");
    }

    private void startTask() {
        if (task != null) task.cancel();
        task = getServer().getScheduler().runTaskTimer(this, new Runnable() {
            @Override
            public void run() {
                tick();
            }
        }, 20L, interval);
    }

    private static <E extends Enum<E>> E parseEnum(Class<E> type, String name, E def) {
        if (name == null) return def;
        try {
            return Enum.valueOf(type, name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return def;
        }
    }

    private static int minorVersion() {
        try {
            // contoh: "1.21.4-R0.1-SNAPSHOT"
            String v = Bukkit.getBukkitVersion().split("-")[0];
            return Integer.parseInt(v.split("\\.")[1]);
        } catch (Throwable t) {
            return 16;
        }
    }

    // ------------------------------------------------------------ main loop

    private void tick() {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            State s = states.get(viewer.getUniqueId());
            Player target = null;
            if (viewer.hasPermission("crosshairinfo.see")
                    && !disabledWorlds.contains(viewer.getWorld().getName())) {
                target = findTarget(viewer);
            }

            if (target == null) {
                if (s != null && s.visible) onMiss(viewer, s);
                continue;
            }
            if (s == null) {
                s = new State();
                states.put(viewer.getUniqueId(), s);
            }
            show(viewer, s, target);
        }
    }

    private void onMiss(Player viewer, State s) {
        s.miss++;
        if (s.miss > graceCycles) {
            hide(viewer, s);
            return;
        }
        if (smoothHide && s.bar != null) {
            // bar mengecil halus selama masa tunggu
            s.shown *= 0.6;
            applyProgress(s);
        }
    }

    private void hide(Player viewer, State s) {
        if (s.bar != null) s.bar.removePlayer(viewer);
        s.visible = false;
        s.target = null;
        s.miss = 0;
    }

    private void show(Player viewer, State s, Player t) {
        double max = maxHealth(t);
        double hp = Math.max(0.0, Math.min(t.getHealth(), max));
        double ratio = max > 0 ? hp / max : 0.0;

        boolean fresh = !s.visible || !t.getUniqueId().equals(s.target);
        s.target = t.getUniqueId();
        s.miss = 0;

        String title = buildTitle(t, ratio);
        if (s.bar == null) {
            s.bar = Bukkit.createBossBar(title, barColor, barStyle);
            s.title = title;
        } else if (!title.equals(s.title)) {
            s.bar.setTitle(title);
            s.title = title;
        }

        if (fresh) {
            s.shown = ratio;
        } else {
            double d = ratio - s.shown;
            s.shown = Math.abs(d) < 0.01 ? ratio : s.shown + d * 0.5;
        }
        applyProgress(s);

        if (!s.visible) {
            s.bar.addPlayer(viewer);
            s.visible = true;
        }
    }

    private void applyProgress(State s) {
        double p = Math.max(0.0, Math.min(1.0, s.shown));
        if (Math.abs(p - s.bar.getProgress()) > 0.001) s.bar.setProgress(p);
    }

    // ------------------------------------------------------------ targeting

    private Player findTarget(final Player viewer) {
        World w = viewer.getWorld();
        Location eye = viewer.getEyeLocation();

        // cek murah dulu: ada pemain lain di dekat? kalau tidak, tidak usah raytrace
        double lim = (range + 1.5) * (range + 1.5);
        boolean near = false;
        for (Player o : w.getPlayers()) {
            if (o != viewer && o.getLocation().distanceSquared(eye) <= lim) {
                near = true;
                break;
            }
        }
        if (!near) return null;

        Vector dir = eye.getDirection();
        RayTraceResult er = w.rayTraceEntities(eye, dir, range, rayWidth, new java.util.function.Predicate<Entity>() {
            @Override
            public boolean test(Entity e) {
                return e instanceof Player && e != viewer && visibleTo(viewer, (Player) e);
            }
        });
        if (er == null || !(er.getHitEntity() instanceof Player)) return null;
        Player t = (Player) er.getHitEntity();

        // jangan tampil kalau terhalang block
        Vector hit = er.getHitPosition();
        if (hit != null) {
            double dist = hit.distance(eye.toVector());
            RayTraceResult br = w.rayTraceBlocks(eye, dir, dist, FluidCollisionMode.NEVER, true);
            if (br != null) return null;
        }
        return t;
    }

    private boolean visibleTo(Player viewer, Player t) {
        if (!viewer.canSee(t)) return false;
        if (t.getGameMode() == GameMode.SPECTATOR) return false;
        for (MetadataValue mv : t.getMetadata("vanished")) {
            if (mv.asBoolean()) return false;
        }
        return essentials == null || !essentials.vanished(t);
    }

    // ------------------------------------------------------------ title

    @SuppressWarnings("deprecation")
    private double maxHealth(Player t) {
        try {
            double m = t.getMaxHealth();
            return m > 0 ? m : 20.0;
        } catch (Throwable ex) {
            return 20.0;
        }
    }

    private String buildTitle(Player t, double ratio) {
        StringBuilder sb = new StringBuilder(64);

        String rank = rankOf(t);
        if (!rank.isEmpty()) sb.append(rank).append(ChatColor.RESET).append(' ');

        sb.append(colorize(nameColor)).append(nameOf(t));
        sb.append(colorize(separator)).append(hearts(ratio));

        if (moneyEnabled && vault != null) {
            try {
                String amount = String.format(Locale.US, "%,.0f", vault.balance(t));
                sb.append(colorize(separator)).append(colorize(String.format(moneyFormat, amount)));
            } catch (Throwable ignored) {
                // economy bermasalah -> lewati saja, jangan sampai error tiap tick
            }
        }
        return sb.toString();
    }

    private String nameOf(Player t) {
        if (useNick && essentials != null) {
            String nick = essentials.nickname(t);
            if (nick != null) return colorize(nick) + ChatColor.RESET;
        }
        return t.getName();
    }

    private String rankOf(Player t) {
        if (!rankEnabled || luckPerms == null) return "";
        try {
            if (usePrefix) {
                String pre = luckPerms.prefix(t);
                if (pre != null && !pre.trim().isEmpty()) return colorize(pre.trim());
            }
            if (fallbackGroup) {
                String g = luckPerms.group(t);
                if (g != null && !g.isEmpty() && !hideGroups.contains(g.toLowerCase(Locale.ROOT))) {
                    String pretty = Character.toUpperCase(g.charAt(0)) + g.substring(1);
                    return colorize(groupFormat.replace("{group}", pretty));
                }
            }
        } catch (Throwable ignored) {
            // LuckPerms belum siap / user belum ter-load
        }
        return "";
    }

    /** 10 hati, setengah hati dihitung, tanpa angka. */
    private String hearts(double ratio) {
        int units = (int) Math.ceil(ratio * HEARTS * 2 - 1e-9); // 0..20, ada darah = minimal setengah hati
        if (ratio <= 0) units = 0;
        int full = units / 2;
        int half = units % 2;
        int empty = HEARTS - full - half;

        StringBuilder sb = new StringBuilder(HEARTS * 3 + 8);
        if (full > 0) {
            sb.append(colorize(heartFull));
            for (int i = 0; i < full; i++) sb.append(heartSymbol);
        }
        if (half > 0) sb.append(colorize(heartHalf)).append(heartSymbol);
        if (empty > 0) {
            sb.append(colorize(heartEmpty));
            for (int i = 0; i < empty; i++) sb.append(heartSymbol);
        }
        return sb.toString();
    }

    private String colorize(String s) {
        if (s == null || s.isEmpty()) return "";
        Matcher m = HEX.matcher(s);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            if (hexSupported) {
                StringBuilder r = new StringBuilder("&x");
                for (char ch : m.group(1).toCharArray()) r.append('&').append(ch);
                m.appendReplacement(out, Matcher.quoteReplacement(r.toString()));
            } else {
                m.appendReplacement(out, "");
            }
        }
        m.appendTail(out);
        return ChatColor.translateAlternateColorCodes('&', out.toString());
    }

    // ------------------------------------------------------------ events & command

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        State s = states.remove(e.getPlayer().getUniqueId());
        if (s != null && s.bar != null) s.bar.removeAll();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            for (Player p : Bukkit.getOnlinePlayers()) {
                State s = states.get(p.getUniqueId());
                if (s != null && s.visible) hide(p, s);
            }
            states.clear();
            loadSettings();
            startTask();
            sender.sendMessage(ChatColor.GREEN + "CrosshairInfo config di-reload.");
        } else {
            sender.sendMessage(ChatColor.YELLOW + "Pakai: /" + label + " reload");
        }
        return true;
    }
}
