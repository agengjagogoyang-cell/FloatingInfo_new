package id.crosshair.info;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

final class VaultHook {

    private final Economy eco;

    private VaultHook(Economy eco) {
        this.eco = eco;
    }

    static VaultHook create() {
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : new VaultHook(rsp.getProvider());
    }

    double balance(Player p) {
        return eco.getBalance(p);
    }
}
