package id.crosshair.info;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;

/** EssentialsX lewat reflection: tidak perlu dependency saat compile, aman beda versi. */
final class EssentialsHook {

    private final Plugin ess;
    private final Method getUser;
    private Method getNickname;
    private Method isVanished;

    private EssentialsHook(Plugin ess, Method getUser) {
        this.ess = ess;
        this.getUser = getUser;
    }

    static EssentialsHook create() {
        try {
            Plugin ess = Bukkit.getPluginManager().getPlugin("Essentials");
            if (ess == null) return null;
            Method m = ess.getClass().getMethod("getUser", Player.class);
            return new EssentialsHook(ess, m);
        } catch (Throwable t) {
            return null;
        }
    }

    private Object user(Player p) {
        try {
            return getUser.invoke(ess, p);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Nickname /nick, atau null kalau tidak ada. */
    String nickname(Player p) {
        try {
            Object u = user(p);
            if (u == null) return null;
            if (getNickname == null) getNickname = u.getClass().getMethod("getNickname");
            Object n = getNickname.invoke(u);
            if (n == null) return null;
            String s = n.toString();
            return s.isEmpty() ? null : s;
        } catch (Throwable t) {
            return null;
        }
    }

    boolean vanished(Player p) {
        try {
            Object u = user(p);
            if (u == null) return false;
            if (isVanished == null) isVanished = u.getClass().getMethod("isVanished");
            return Boolean.TRUE.equals(isVanished.invoke(u));
        } catch (Throwable t) {
            return false;
        }
    }
}
