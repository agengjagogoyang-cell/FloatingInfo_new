package id.crosshair.info;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;

/** Pakai reflection supaya tetap bisa di-compile walau API head icon belum ada. */
final class HeadIcon {
    private static Method playerHead;
    private static Method componentObject;

    static {
        try {
            Class<?> contents = Class.forName("net.kyori.adventure.text.object.ObjectContents");
            playerHead = contents.getMethod("playerHead", java.util.UUID.class);
            componentObject = Component.class.getMethod("object", Class.forName("net.kyori.adventure.text.object.ObjectContents"));
        } catch (Throwable t) {
            playerHead = null;
            componentObject = null;
        }
    }

    private HeadIcon() {}

    static boolean available() {
        return playerHead != null && componentObject != null;
    }

    static Component of(Player p) {
        try {
            Object c = playerHead.invoke(null, p.getUniqueId());
            return (Component) componentObject.invoke(null, c);
        } catch (Throwable t) {
            return Component.text("\u263B");
        }
    }
}
